
import React from 'react';
import { CiUser } from "react-icons/ci";
import { TiCloudStorageOutline } from "react-icons/ti";
import { MdOutlineMail } from "react-icons/md";
import { TiTickOutline } from "react-icons/ti";
import { MdOutlineDashboard } from "react-icons/md";
import { GrGrow } from "react-icons/gr";
import { BsFillPuzzleFill } from "react-icons/bs";
import { FaQuestionCircle } from "react-icons/fa";
import { MdSupportAgent } from "react-icons/md";
import { IoIosArrowDown } from "react-icons/io";

function Home() {
  return (
    <div className="home-container">
      
      <div className="sidenav">
        <ul className='navitem'>
          <li ><a className='dash' href="#basic"><MdOutlineDashboard />&nbsp;Dashboard</a></li>
          <li><a href="#standard"><GrGrow />Perks&nbsp;</a></li>
          <li><a href="#premium"><BsFillPuzzleFill />&nbsp;Addons</a></li>
          <li><a href="#faq"><FaQuestionCircle />&nbsp;FAQ</a></li>
          <li><a href="#support"><MdSupportAgent />Support</a></li>
        </ul>
      </div>
      <div className='companyname'>XYZ Enterprises pvt.Ltd&nbsp; </div><div className='arrow'><IoIosArrowDown /></div>
      <div className='plan'><b><h3>Choose a plan that's just right for you&nbsp;!</h3></b></div>
      <div>Monthly Anually</div>

      <div className="content-container" style={{ display: 'flex', marginTop: '180px', marginLeft: '100px' }}>
         
           <div  className="card-content">
          <p className="card-title">Basic</p>
          <p className='nine'>$89.99/mo</p>
          <p>9.99/mo</p>
          <p className='get1'>Get Started&nbsp;--&gt;</p>
          <hr />
          <p>What you'll get:</p>
          <ul className="features-list">
            <li>Up to 25 users</li>
            <li><TiCloudStorageOutline />Up to 25GB storage</li>
            <li><MdOutlineMail />Email support</li>
          </ul>
          <button className="explore-button">Explore Features</button>
        </div>

        <div id="standard" className="card-content">
          <p className="card-title">Standard</p>
          <p className='nine'>$99.99/mo</p>
          <p>99.99/mo</p>
          <p className='get2'>Get Started&nbsp;--&gt;</p>
          <hr />
          <p>What you'll get:</p>
          <ul className="features-list">
            <li><CiUser />Up to 50 users</li>
            <li><TiCloudStorageOutline />Up to 60GB storage</li>
            <li><MdOutlineMail />Email and chat support</li>
          </ul>
          <button className="explore-button">Explore Features</button>
        </div>

        <div id="premium" className='card-content'>
          <p className='card-title'>Premium</p>
          <p className='nine'>$199.99/mo</p>
          <p>199.99/mo</p>
          <p className='get3'>Get Started&nbsp;--&gt;</p>
          <hr />
          <p className='what'>What you'll get:</p>
          <ul className="features-list">
            <li><CiUser />Up to 100 users</li>
            <li><TiCloudStorageOutline />Up to 100GB storage</li>
            <li><MdOutlineMail />Email, chat, and phone support</li>
          </ul>
          <button className="explore-button">Explore Features</button>
        </div>
      </div>

      <div className='card-hori' >
        <div className='left'>
          <p className="free">Free Forever</p>
          <h2>Free Starter</h2>
          <p>The quickest and easiest way to try protocols with basic functionalities</p>
          <button className='start'>Get Started&nbsp;--&gt;</button>
        </div>
        <div className='right'>
          <p>what you'll get:</p>
          <p className='upto'> <CiUser />&nbsp;upto 8 users</p>


          <p className='upto1'> <TiCloudStorageOutline />&nbsp;upto 3gb storage</p>
          <p><MdOutlineMail />&nbsp;Email support</p>
          <p><TiTickOutline />&nbsp;Basics of Documents ,Task flow</p>
          <p>voting,Accounting,Banking,Notes,</p>
           <p> Investor,Director</p>
           <p> Management included</p>
        </div>
      </div>

      <div className='card-hori1' >
        <div className='left1'>
          <p className='lets'>Let's connect</p>
          <h4 className='enterprise'>Enterprise plan</h4>
          <div className='effort' >
          <p>Effortlessly customize and fine-tune services as</p>
            <p> needs shift, ensuring the perfect tools for success</p></div>
          <button className='contact'> Contact Us&nbsp;--&gt;</button>
        </div>
        <div className='right1'>
          <p>what you'll get:</p>
          <p> <CiUser />&nbsp;More than 75 users</p>
          <p><TiTickOutline />&nbsp;Customization of all</p> 
          <p> other features</p>
        </div>
      </div>
    </div>
  );
}

export default Home;
